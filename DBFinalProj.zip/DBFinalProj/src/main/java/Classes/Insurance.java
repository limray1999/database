package Classes;

public class Insurance {
    private int planID;
    private String planName;
    private String description;
    private float cost;
    private  static  int nextid = DBoperations.next_ins_id();

    public Insurance(){}

    public Insurance(int planID, String planName, String description, float cost){
        this.planName = planName;
        this.description = description;
        this.cost = cost;
        this.planID = planID;
    }

    public String getPlanName(){
        return this.planName;
    }
    public String getDescription(){
        return this.description;
    }
    public int getPlanID(){
        return this.planID;
    }
    public float getCost(){
        return this.cost;
    }

    public void setDescription(String description){
        this.description = description;
    }
    public void setCost(float cost){
        this.cost = cost;
    }
}
