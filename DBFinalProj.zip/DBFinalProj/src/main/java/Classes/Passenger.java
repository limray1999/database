package Classes;

import java.time.LocalDate;
import java.util.Date;

public class Passenger {
    private int PassengerID;
    private String firstName;
    private String lastName;
    private Date Birthday;
    private String Nationality;
    private String Gender;
    private String PassportNumber;
    private Date PassportExpiryDate;
    private String PassengerType;


    public Passenger(int PassengerID, String firstName, String lastName, Date Birthday,
                     String Nationality, String Gender, String PassportNumber, Date PassportExpiryDate,
                     String PassengerType) {

        super();
        this.PassengerID = PassengerID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.Birthday = Birthday;
        this.Nationality = Nationality;
        this.Gender = Gender;
        this.PassportNumber = PassportNumber;
        this.PassportExpiryDate = PassportExpiryDate;
        this.PassengerType = PassengerType;

    }

    public int getPassengerID() {
        return PassengerID;
    }
    public String getFirstName() {
        return firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public Date getBirthday () {
        return Birthday;
    }
    public String getNationality() {
        return Nationality;
    }
    public String getGender() {
        return Gender;
    }
    public String getPassportNumber() {
        return PassportNumber;
    }
    public Date getPassportExpiryDate() {
        return PassportExpiryDate;
    }
    public String getPassengerType() {
        return PassengerType;
    }

}
