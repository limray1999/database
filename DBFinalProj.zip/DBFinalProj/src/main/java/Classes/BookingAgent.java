package Classes;

import java.awt.print.Book;

public class BookingAgent {
    private int passengerid;
    private String baname;
    private String webaddress;
    private String phonenumber;

    public BookingAgent(){}
    public BookingAgent(int passengerid, String baname, String webaddress, String phonenumber) {
        this.passengerid = passengerid;
        this.baname = baname;
        this.webaddress = webaddress;
        this.phonenumber = phonenumber;
    }

    public String getBookingAgentName() {
        return this.baname;
    }
    public String getWebAddress() {
        return this.webaddress;
    }
    public String getPhoneNumber () {
        return this.phonenumber;
    }
    public int getPassengerid(){return this.passengerid;}


}
