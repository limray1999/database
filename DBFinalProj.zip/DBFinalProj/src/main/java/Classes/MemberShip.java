package Classes;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MemberShip {
    private int passengerid;
    private String membershipname;
    private String associatedairline;
    private Date startdate;
    private Date enddate;

    public MemberShip(){}
    public MemberShip(int passengerid, String membershipname, String associatedairline, Date startdate){
        this.membershipname = membershipname;
        this.associatedairline = associatedairline;
        this.startdate = startdate;
        this.passengerid = passengerid;
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try {
            this.enddate = df.parse("2999-12-31");
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
    public MemberShip(int passengerid, String membershipname, String associatedairline, Date startdate, Date enddate) {
        this.membershipname = membershipname;
        this.associatedairline = associatedairline;
        this.startdate = startdate;
        this.enddate = enddate;
        this.passengerid = passengerid;
    }

    public String getMembershipName() {
        return this.membershipname;
    }
    public String getAssociatedAirline() {
        return this.associatedairline;
    }
    public Date getStartDate () {
        return this.startdate;
    }
    public Date getEndDate(){return this.enddate;}
    public int getPassengerid(){return this.passengerid;}

}
