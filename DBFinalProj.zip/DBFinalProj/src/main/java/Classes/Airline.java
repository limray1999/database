package Classes;

public class Airline {
    private int id;
    private String name;
    private String mainhub;
    private String headquater;
    private String country;
    private String airportcode;

    public Airline(){}
    public Airline(int id, String name, String mainhub, String headquater, String country, String airportcode){
        this.id = id;
        this.name = name;
        this.mainhub = mainhub;
        this.headquater = headquater;
        this.country = country;
        this.airportcode = airportcode;
    }

    public int getId(){
        return this.id;
    }
    public String getName(){
        return this.name;
    }
    public String getCountry(){
        return this.country;
    }
    public String getMainhub(){
        return this.mainhub;
    }
    public String getHeadquater(){
        return this.headquater;
    }
    public String getAirportcode(){
        return this.airportcode;
    }
}
