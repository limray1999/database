package Classes;

import java.io.Serializable;

public class LoginAccount {

    private String username;
    private String password;
    private static int nextid = DBoperations.next_pas_id();
    private int passengerid;


    public LoginAccount() {}

    public LoginAccount(String username, String password){
        this.username = username;
        this.password = password;
        this.passengerid = LoginAccount.nextid++;
    }

    public String getUsername() {
        return this.username;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getPassengerid() { return this.passengerid; }
}
