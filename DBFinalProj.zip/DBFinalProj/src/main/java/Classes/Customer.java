package Classes;

import com.sun.xml.internal.ws.server.ServerRtException;

public class Customer{
    private int passengerid;
    private String street;
    private String city;
    private String state;
    private String zipcode;
    private String country;
    private String email;
    private String contactnumber;
    private String efname;
    private String elname;
    private String econtact;
    private String customertype;

    public Customer(){}
    public Customer(int pid, String street, String city, String state, String zipcode, String country, String email,String contactnumber, String efname, String elname, String econtact, String customertype){
        this.passengerid = pid;
        this.street = street;
        this.city = city;
        this.state = state;
        this.zipcode = zipcode;
        this.country = country;
        this.email = email;
        this.contactnumber = contactnumber;
        this.efname = efname;
        this.elname = elname;
        this.econtact = econtact;
        this.customertype = customertype;
    }

    public int getPassengerid(){return this.passengerid;}
    public String getCity(){return this.city;}
    public String getStreet(){return this.street;}
    public String getCountry(){return this.country;}
    public String getState(){return this.state;}
    public String getZipcode(){return this.zipcode;}
    public String getEmail(){return this.email;}
    public String getContactnumber(){return this.contactnumber;}
    public String getEfname(){return this.efname;}
    public String getElname(){return this.elname;}
    public String getCustomertype(){return this.customertype;}
    public String getEcontact(){return this.econtact;}
}
