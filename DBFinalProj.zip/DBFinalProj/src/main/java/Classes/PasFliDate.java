package Classes;

import java.util.Date;

public class PasFliDate {
    private int pid;
    private int fid;
    private Date fdate;
    private int mpid;
    private int ccid;
    private int srid;

    public PasFliDate(){}
    public PasFliDate(int pid, int fid, Date fdate, int mpid, int ccid, int srid){
        this.pid = pid;
        this.fid = fid;
        this.fdate = fdate;
        this.mpid = mpid;
        this.ccid = ccid;
        this.srid = srid;
    }

    public Date getFdate(){return this.fdate;}
    public int getPid(){return this.pid;}
    public int getFid(){return this.fid;}
    public int getMpid(){return this.mpid;}
    public int getCcid(){return this.ccid;}
    public int getSrid(){return this.srid;}
}
