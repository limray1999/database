package Classes;

public class Airport {
    private String code;
    private String name;
    private String city;
    private String country;
    private String type;

    public Airport(){}
    public Airport(String code, String name, String city, String country, String type){
        this.code = code;
        this.name = name;
        this.city = city;
        this.country = country;
        this.type = type;
    }

    public String getCode(){
        return this.code;
    }
    public String getName(){
        return this.name;
    }
    public String getCity(){
        return this.city;
    }
    public String getCountry(){
        return this.country;
    }
    public String getType(){
        return this.type;
    }
}
