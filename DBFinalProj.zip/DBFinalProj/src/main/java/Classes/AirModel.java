package Classes;

public class AirModel {
    private int id;
    private String name;
    private String manufacturer;
    private int numOfEngines;
    private int numOfFleets;

    public AirModel(){}
    public AirModel(int id, String name, String manufactor, int numOfEngines, int numOfFleets){
        this.id = id;
        this.name = name;
        this.manufacturer = manufactor;
        this.numOfEngines = numOfEngines;
        this.numOfFleets = numOfFleets;
    }

    public int getId(){
        return this.id;
    }
    public String getName(){
        return this.name;
    }
    public String getManufactor(){
        return this.manufacturer;
    }
    public int getNumOfEngines(){
        return this.numOfEngines;
    }
    public int getNumOfFleets(){
        return this.numOfFleets;
    }
}
