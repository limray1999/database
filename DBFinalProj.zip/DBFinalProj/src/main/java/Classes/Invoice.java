package Classes;

import java.util.Date;

public class Invoice {
    private int invoicenumber;
    private Date invoicedate;
    private float amount;

    public Invoice(){}
    public Invoice(int invoicenumber, Date date, float amount){
        this.invoicedate = date;
        this.invoicenumber = invoicenumber;
        this.amount = amount;
    }

    public int getInvoicenumber(){return this.invoicenumber;}
    public Date getInvoicedate(){return this.invoicedate;}
    public float getAmount(){return this.amount;}
}
