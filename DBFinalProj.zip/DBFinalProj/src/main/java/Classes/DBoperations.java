package Classes;

import java.sql.*;

public class DBoperations {

    private static final String url = "jdbc:mysql://localhost:3306/DBFinalProj";
    private static final String user = "root";
    private static final String password = "123456";

    public static boolean validate(String username, String password){
        boolean status = false;
        try {
            Connection connection = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement preparedStatement = connection.prepareStatement("select * from login where username = ? and password = ? ");
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            ResultSet rs = preparedStatement.executeQuery();
            status = rs.next();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static int getUserPid(String username){
        int pid = 0;
        try {
            Connection connection = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement preparedStatement = connection.prepareStatement("select passengerid from login where username = ?");
            preparedStatement.setString(1, username);
            ResultSet rs = preparedStatement.executeQuery();
            rs.next();
            pid = rs.getInt("passengerid");
        } catch (SQLException e) {
            printSQLException(e);
        }
        return pid;
    }

    public static  boolean adminValidate(AdminAccount account){
        boolean status = false;
        try {
            Connection connection = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement preparedStatement = connection.prepareStatement("select * from adminlogin where username = ? and password = ? ");
            preparedStatement.setString(1, account.getUsername());
            preparedStatement.setString(2, account.getPassword());
            ResultSet rs = preparedStatement.executeQuery();
            status = rs.next();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static int next_pas_id(){
        int nextid = 100000;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select max(passengerid) as current from login");
            if(rs.next()) nextid = Math.max(rs.getInt("current")+1, nextid);
        } catch (SQLException e) {
            printSQLException(e);
        }
        return nextid;
    }

    public static boolean customerValidate(int pid){
        boolean status = false;
        try {
            Connection connection = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement preparedStatement = connection.prepareStatement("select * from ml_oz_customer where passengerid = ?");
            preparedStatement.setInt(1, pid);
            ResultSet rs = preparedStatement.executeQuery();
            status = rs.next();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean insertCustomer(Customer cus){
        boolean status = false;
        try {
            Connection myConn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = myConn.prepareStatement("insert into ml_oz_customer values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            insert.setInt(1, cus.getPassengerid());
            insert.setString(2, cus.getStreet());
            insert.setString(3, cus.getCity());
            insert.setString(4, cus.getState());
            insert.setString(5, cus.getZipcode());
            insert.setString(6, cus.getCountry());
            insert.setString(7, cus.getEmail());
            insert.setString(8, cus.getContactnumber());
            insert.setString(9, cus.getEfname());
            insert.setString(10, cus.getElname());
            insert.setString(11, cus.getEcontact());
            insert.setString(12, cus.getCustomertype());
            int r = insert.executeUpdate();
            if(r>0) status = true;
            PreparedStatement update = myConn.prepareStatement("update ml_oz_passenger set passengertype = 'C' where passengerid = ?");
            update.setInt(1, cus.getPassengerid());
            update.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static ResultSet showPassenger(){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from ml_oz_passenger");
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static boolean insertBA(BookingAgent ba){
        boolean status = false;
        try {
            Connection myConn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = myConn.prepareStatement("insert into ml_oz_ba values (?, ?, ?, ?)");
            insert.setInt(1, ba.getPassengerid());
            insert.setString(2, ba.getBookingAgentName());
            insert.setString(3, ba.getWebAddress());
            insert.setString(4, ba.getPhoneNumber());
            int r = insert.executeUpdate();
            if(r>0) status = true;
            PreparedStatement update = myConn.prepareStatement("update ml_oz_customer set customertype = 'B' where passengerid = ?");
            update.setInt(1, ba.getPassengerid());
            update.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean insertMB(MemberShip mb){
        boolean status = false;
        try {
            Connection myConn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = myConn.prepareStatement("insert into ml_oz_member values (?, ?, ?, ?, ?)");
            insert.setInt(1, mb.getPassengerid());
            insert.setString(2, mb.getMembershipName());
            insert.setString(3, mb.getAssociatedAirline());
            insert.setDate(4, new java.sql.Date(mb.getStartDate().getTime()));
            insert.setDate(5, new java.sql.Date(mb.getEndDate().getTime()));
            int r = insert.executeUpdate();
            if(r>0) status = true;
            PreparedStatement update = myConn.prepareStatement("update ml_oz_customer set customertype = 'M' where passengerid = ?");
            update.setInt(1, mb.getPassengerid());
            update.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static ResultSet showPassenger(int pid){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from ml_oz_passenger where passengerid = " + pid);
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static ResultSet showPassenger(String fname, String lname){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement show = conn.prepareStatement("select * from ml_oz_passenger where pfname = ? and plname = ?");
            show.setString(1, fname);
            show.setString(2, lname);
            rs = show.executeQuery();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static boolean deletePassenger(int id){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement delete = conn.prepareStatement("delete from ml_oz_passenger where passengerid = ?");
            delete.setInt(1, id);
            int r = delete.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean insertPassenger(Passenger pass){
        boolean status = false;
        try {
            Connection myConn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = myConn.prepareStatement("insert into ml_oz_passenger values (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            insert.setInt(1, pass.getPassengerID());
            insert.setString(2, pass.getFirstName());
            insert.setString(3, pass.getLastName());
            insert.setDate(4, new java.sql.Date(pass.getBirthday().getTime()));
            insert.setString(5, pass.getNationality());
            insert.setString(6, pass.getGender());
            insert.setString(7, pass.getPassportNumber());
            insert.setDate(8, new java.sql.Date(pass.getPassportExpiryDate().getTime()));
            insert.setString(9, pass.getPassengerType());
            int r = insert.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static ResultSet showLoginAccount(){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from login");
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static ResultSet showLoginAccount(String username){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement show = conn.prepareStatement("select * from login where username = ?");
            show.setString(1, username);
            rs = show.executeQuery();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static boolean insertLoginAccount(LoginAccount account){
        boolean status = false;
        try {
            Connection myConn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = myConn.prepareStatement("insert into login (username, password, passengerid) values (?, ?, ?)");
            insert.setString(1, account.getUsername());
            insert.setString(2, account.getPassword());
            insert.setInt(3, account.getPassengerid());
            int r = insert.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean deleteLoginAccount(String username){
        boolean status = false;
        try {
            Connection myConn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement delete = myConn.prepareStatement("delete from login where username = ?");
            delete.setString(1, username);
            int r = delete.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static ResultSet showInsurance(){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from ml_oz_insurance");
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static boolean insertInsurance(Insurance ins){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = conn.prepareStatement("insert into ml_oz_insurance (planid, planname, description, cost) values (?, ?, ?, ?)");
            insert.setInt(1, ins.getPlanID());
            insert.setString(2, ins.getPlanName());
            insert.setString(3, ins.getDescription());
            insert.setFloat(4,ins.getCost());
            int r = insert.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean deleteInsruance(int planid){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement delete = conn.prepareStatement("delete from ml_oz_insurance where planid = ?");
            delete.setInt(1, planid);
            int r = delete.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean insUpdateName(int pid, String name){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement set = conn.prepareStatement("update ml_oz_insurance set planname = ? where planid = ?");
            set.setString(1, name);
            set.setInt(2, pid);
            int r = set.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean insUpdateDes(int pid, String des){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement set = conn.prepareStatement("update ml_oz_insurance set description = ? where planid = ?");
            set.setString(1, des);
            set.setInt(2, pid);
            int r = set.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean insUpdatecost(int pid, float cost){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement set = conn.prepareStatement("update ml_oz_insurance set cost = ? where planid = ?");
            set.setFloat(1, cost);
            set.setInt(2, pid);
            int r = set.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static int next_ins_id(){
        int nextid = 600001;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select max(planid) as current from ml_oz_insurance");
            if(rs.next()) nextid = Math.max(rs.getInt("current")+1, nextid);
        } catch (SQLException e) {
            printSQLException(e);
        }
        return nextid;
    }

    public static ResultSet showAirport(){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from ml_oz_airport");
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static boolean insertAirport(Airport ap){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = conn.prepareStatement("insert into ml_oz_airport (airportcode, airportname, airportcity, airportcountry, airporttype) values (?, ?, ?, ?, ?)");
            insert.setString(1, ap.getCode());
            insert.setString(2, ap.getName());
            insert.setString(3, ap.getCity());
            insert.setString(4, ap.getCountry());
            insert.setString(5, ap.getType());
            int r = insert.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean deleteAirport(String code){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement delete = conn.prepareStatement("delete from ml_oz_airport where airportcode = ?");
            delete.setString(1, code);
            int r = delete.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean apUpdateCode(String code, String newcode){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement set = conn.prepareStatement("update ml_oz_airport set code = ? where code = ?");
            set.setString(1, newcode);
            set.setString(2, code);
            int r = set.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean apUpdateName(String code, String name){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement set = conn.prepareStatement("update ml_oz_airport set name = ? where code = ?");
            set.setString(1, name);
            set.setString(2, code);
            int r = set.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean apUpdateCity(String code, String city){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement set = conn.prepareStatement("update ml_oz_airport set city = ? where code = ?");
            set.setString(1, city);
            set.setString(2, code);
            int r = set.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean apUpdateCountry(String code, String country){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement set = conn.prepareStatement("update ml_oz_insurance set country= ? where code = ?");
            set.setString(1, country);
            set.setString(2, code);
            int r = set.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean apUpdateType(String code, String type){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement set = conn.prepareStatement("update ml_oz_insurance set type = ? where code = ?");
            set.setString(1, type);
            set.setString(2, code);
            int r = set.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static ResultSet showMealPlan(){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from ml_oz_mealplan");
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static boolean insertMealPlan(MealPlan mp){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = conn.prepareStatement("insert into ml_oz_mealplan (mp_id, mp_name) values (?, ?)");
            insert.setInt(1, mp.getId());
            insert.setString(2, mp.getName());
            int r = insert.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean deleteMealPlan(int id){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement delete = conn.prepareStatement("delete from ml_oz_mealplan where mp_id = ?");
            delete.setInt(1, id);
            int r = delete.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean mpUpdatename(int id, String name){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement set = conn.prepareStatement("update ml_oz_mealplan set mp_name = ? where mp_id = ?");
            set.setString(1, name);
            set.setInt(2, id);
            int r = set.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static ResultSet showSepcialRequ(){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from ml_oz_spec_requ");
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static boolean insertSepcialRequ(SpecialRequ sr){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = conn.prepareStatement("insert into ml_oz_spec_requ (request_id, request_name) values (?, ?)");
            insert.setInt(1, sr.getId());
            insert.setString(2, sr.getName());
            int r = insert.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean deleteSepcialRequ(int id){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement delete = conn.prepareStatement("delete from ml_oz_spec_requ where request_id = ?");
            delete.setInt(1, id);
            int r = delete.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean srUpdatename(int id, String name){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement set = conn.prepareStatement("update ml_oz_spec_requ set request_name = ? where request_id = ?");
            set.setString(1, name);
            set.setInt(2, id);
            int r = set.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static ResultSet showCabinClass(){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from ml_oz_cabin_class");
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static boolean insertCabinClass(CabinClass cc){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = conn.prepareStatement("insert into ml_oz_cabin_class (cc_id, cc_name) values (?, ?)");
            insert.setInt(1, cc.getId());
            insert.setString(2, cc.getName());
            int r = insert.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean deleteCabinClass(int id){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement delete = conn.prepareStatement("delete from ml_oz_cabin_class where cc_id = ?");
            delete.setInt(1, id);
            int r = delete.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean ccUpdatename(int id, String name){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement set = conn.prepareStatement("update ml_oz_cabin_class set cc_name = ? where cc_id = ?");
            set.setString(1, name);
            set.setInt(2, id);
            int r = set.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static ResultSet showAirline(){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from ml_oz_airline");
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static boolean insertAirline(Airline al){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = conn.prepareStatement("insert into ml_oz_airline (airid, airlinename, mainhub, headquarter, aircountry, airportcode) values (?, ?, ?, ?, ?, ?)");
            insert.setInt(1, al.getId());
            insert.setString(2, al.getName());
            insert.setString(3, al.getMainhub());
            insert.setString(4, al.getHeadquater());
            insert.setString(5, al.getCountry());
            insert.setString(6, al.getAirportcode());
            int r = insert.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean deleteAirline(int id){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement delete = conn.prepareStatement("delete from ml_oz_airline where airid = ?");
            delete.setInt(1, id);
            int r = delete.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static ResultSet showAirModel(){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from ml_oz_airmodel");
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static boolean insertAirModel(AirModel am){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = conn.prepareStatement("insert into ml_oz_airmodel (modelid, modelname, manufacturer, numofengines, numoffleets) values (?, ?, ?, ?, ?)");
            insert.setInt(1, am.getId());
            insert.setString(2, am.getName());
            insert.setString(3, am.getManufactor());
            insert.setInt(4, am.getNumOfEngines());
            insert.setInt(5, am.getNumOfFleets());
            int r = insert.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean deleteAirModel(int id){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement delete = conn.prepareStatement("delete from ml_oz_airmodel where modelid = ?");
            delete.setInt(1, id);
            int r = delete.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean amUpdateNumOfFleets(int id, int num){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement set = conn.prepareStatement("update ml_oz_airmodel set numoffleets = ? where modelid = ?");
            set.setInt(1, num);
            set.setInt(2, id);
            int r = set.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static ResultSet showCusIns(int cid){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from ml_oz_cus_ins where customerid = " + cid);
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static ResultSet showPasIns(int pid){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from ml_oz_pas_ins where passengerid = " + pid);
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static ResultSet showPasFliDate(int pid){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from ml_oz_pasfli_date where passengerid = " + pid);
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static boolean insertPasFliDate(PasFliDate pfd){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = conn.prepareStatement("insert into ml_oz_pasfli_date values (?, ?, ?, ?, ?, ?)");
            insert.setDate(1, new java.sql.Date(pfd.getFdate().getTime()));
            insert.setInt(2, pfd.getPid());
            insert.setInt(3, pfd.getFid());
            insert.setInt(4, pfd.getMpid());
            insert.setInt(5, pfd.getCcid());
            insert.setInt(6, pfd.getSrid());
            int r = insert.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static float getCost(int planid){
        float cost = 0;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement select = conn.prepareStatement("select cost from ml_oz_insurance where planid = ?");
            select.setInt(1, planid);
            ResultSet rs = select.executeQuery();
            rs.next();
            cost = rs.getFloat("cost");
        } catch (SQLException e) {
            printSQLException(e);
        }
        return cost;
    }

    public static int next_inv_number(){
        int nextid = 100000;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select max(invoicenumber) as current from ml_oz_invoice");
            if(rs.next()) nextid = Math.max(rs.getInt("current")+1, nextid);
        } catch (SQLException e) {
            printSQLException(e);
        }
        return nextid;
    }

    public static int next_payment_id(){
        int nextid = 100000;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select max(paymentid) as current from ml_oz_payment");
            if(rs.next()) nextid = Math.max(rs.getInt("current")+1, nextid);
        } catch (SQLException e) {
            printSQLException(e);
        }
        return nextid;
    }

    public static boolean insertPayment(Payment payment){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = conn.prepareStatement("insert into ml_oz_payment values (?,?,?,?,?,?,?,?,?)");
            insert.setInt(1, payment.getId());
            insert.setFloat(2, payment.getAmount());
            insert.setString(3, payment.getMethod());
            insert.setInt(4, payment.getCardnumber());
            insert.setString(5, payment.getFnameoncard());
            insert.setString(6, payment.getLnameoncard());
            insert.setDate(7, new java.sql.Date(payment.getEdate().getTime()));
            insert.setInt(8, payment.getInvnumber());
            insert.setDate(9, new java.sql.Date(payment.getPaymentdate().getTime()));
            int r = insert.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static ResultSet showPayment(int invnumber){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from ml_oz_payment where invoicenumber = " + invnumber);
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static ResultSet showInvoice(int invnumber){
        ResultSet rs = null;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from ml_oz_invoice where invoicenumber = " + invnumber);
        } catch (SQLException e) {
            printSQLException(e);
        }
        return rs;
    }

    public static boolean insertInvoice(Invoice inv){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = conn.prepareStatement("insert into ml_oz_invoice values (?, ?, ?)");
            insert.setInt(1, inv.getInvoicenumber());
            insert.setDate(2, new java.sql.Date(inv.getInvoicedate().getTime()));
            insert.setFloat(3, inv.getAmount());
            int r = insert.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }
    public static boolean insertPasIns(int planid, int coverageid, int flightid, java.util.Date fdate){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = conn.prepareStatement("insert into ml_oz_pas_ins values (?, ?, ?, ?)");
            insert.setInt(1, planid);
            insert.setInt(2, flightid);
            insert.setInt(3, coverageid);
            insert.setDate(4, new java.sql.Date(fdate.getTime()));
            int r = insert.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }
    public static boolean insertCusIns(int coverageid, int planid, int passengerid, int flightid, java.util.Date fdate,int invnumber){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = conn.prepareStatement("insert into ml_oz_cus_ins values (?, ?, ?, ?, ?,?)");
            insert.setInt(1, coverageid);
            insert.setInt(2, planid);
            insert.setInt(3, passengerid);
            insert.setDate(4, new java.sql.Date(fdate.getTime()));
            insert.setInt(5, flightid);
            insert.setInt(6, invnumber);
            int r = insert.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static boolean deletePasFliDate(int pid, int fid, java.util.Date date){
        boolean status = false;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            PreparedStatement insert = conn.prepareStatement("delete from ml_oz_pasfli_date where passengerid = ? and flightid = ? and date = ?");
            insert.setInt(1, pid);
            insert.setInt(2, fid);
            insert.setDate(3, new java.sql.Date(date.getTime()));
            int r = insert.executeUpdate();
            if(r>0) status = true;
        } catch (SQLException e) {
            printSQLException(e);
        }
        return status;
    }

    public static float hasPaid(int invnumber){
        float hasPaid = 0;
        try {
            Connection conn = DriverManager.getConnection(DBoperations.url, DBoperations.user, DBoperations.password);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select sum(paymentamount) as haspaid from ml_oz_payment where invoicenumber = "+invnumber+" group by invoicenumber");
            if(rs.next()) hasPaid = rs.getFloat("haspaid");
        } catch (SQLException e) {
            printSQLException(e);
        }
        return hasPaid;
    }

    private static void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
