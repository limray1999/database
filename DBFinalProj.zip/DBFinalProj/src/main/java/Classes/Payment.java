package Classes;

import java.util.Date;

public class Payment {
    private int id;
    private float amount;
    private String method;
    private int cardnumber;
    private String fnameoncard;
    private String lnameoncard;
    private Date edate;
    private int invnumber;
    private Date paymentdate;

    public Payment(){}
    public Payment(int id, float amount, String method, int cardnumber, String fnameoncard, String lnameoncard, Date edate, int invnumber, Date paymentdate){
        this.id = id;
        this.amount = amount;
        this.method = method;
        this.cardnumber = cardnumber;
        this.fnameoncard = fnameoncard;
        this.lnameoncard = lnameoncard;
        this.edate = edate;
        this.invnumber = invnumber;
        this.paymentdate = paymentdate;
    }

    public int getId(){return this.id;}
    public float getAmount(){return this.amount;}
    public String getMethod(){return this.method;}
    public int getCardnumber(){return this.cardnumber;}
    public String getFnameoncard(){return this.fnameoncard;}
    public String getLnameoncard(){return this.lnameoncard;}
    public Date getEdate(){return this.edate;}
    public int getInvnumber(){return this.invnumber;}
    public Date getPaymentdate(){return this.paymentdate;}
}
