import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Main {

    public static  void main(String[] arg) throws ClassNotFoundException {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try{
            System.out.println(df.parse("2022-03-07"));
            System.out.println(new java.sql.Date(df.parse("2022-03-07").getTime()));
            System.out.println(new java.sql.Date(new java.util.Date().getTime()));
        }catch (ParseException e) {
            e.printStackTrace();
        }
    }
}
