package AdminServlets;

import Classes.DBoperations;
import Classes.MealPlan;
import Classes.SpecialRequ;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "AdminSrOperationServlet", urlPatterns = "/admin/AdminSrOperationServlet")
public class AdminSrOperationServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String newname = request.getParameter("newname");
        if(newname != null){
            DBoperations.srUpdatename(Integer.parseInt(newname.substring(0,4)), newname.substring(4));
            System.out.println("Update special request name successfully");
            response.sendRedirect("/adminshowsr.jsp");
            return;
        }
        String delete = request.getParameter("delete");
        if(delete != null) {
            DBoperations.deleteSepcialRequ(Integer.parseInt(delete));
            request.removeAttribute("delete");
            System.out.println("Special Request " + delete + " has bee deleted");
            response.sendRedirect("/adminshowsr.jsp");
            return;
        }
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        if(id == "" && name == ""){
            response.sendRedirect("/adminshowsr.jsp");
            return;
        } else if(id != "" && name != ""){
            SpecialRequ sr = new SpecialRequ(Integer.parseInt(id), name);
            if(DBoperations.insertSepcialRequ(sr)){
                System.out.println("A new special request has been created");
            }else{
                request.setAttribute("error", "Request id has been used");
                System.out.println("Request id has been used");
            }
        }else{
            request.setAttribute("error", "Incomplete Request Information");
            System.out.println("Incomplete Request Information");
        }
        response.sendRedirect("/adminshowsr.jsp");
        return;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
