package AdminServlets;

import Classes.DBoperations;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "AdminDeleteUserServlet", urlPatterns = "/admin/AdminDeleteUserServlet")
public class AdminDeleteUserServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("delete");
        if(username != null){
            DBoperations.deleteLoginAccount(username);
            request.removeAttribute("delete");
            System.out.println("User "+username+" has bee deleted");
        }
        getServletContext().getRequestDispatcher("/adminshowuser.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
