package AdminServlets;

import Classes.DBoperations;
import Classes.Insurance;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "AdminInsOperationServlet", urlPatterns = "/admin/AdminInsOperationServlet")
public class AdminInsOperationServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String newName = request.getParameter("newname");
        if(newName != null){
            if(DBoperations.insUpdateName(Integer.parseInt(newName.substring(0,6)), newName.substring(6))){
                System.out.println("Update insurance name successfully!");
            }
            response.sendRedirect("/adminshowins.jsp");
            return;
        }
        String newDes = request.getParameter("newdes");
        if(newDes != null){
            if(DBoperations.insUpdateDes(Integer.parseInt(newDes.substring(0,6)), newDes.substring(6))){
                System.out.println("Update insurance description successfully!");
            }
            response.sendRedirect("/adminshowins.jsp");
            return;
        }
        String newCost = request.getParameter("newcost");
        if(newCost != null){
            if(DBoperations.insUpdatecost(Integer.parseInt(newCost.substring(0,6)), Float.parseFloat(newCost.substring(6)))){
                System.out.println("Update insurance cost successfully!");
            }
            response.sendRedirect("/adminshowins.jsp");
            return;
        }
        String delete = request.getParameter("delete");
        if(delete != null) {
            DBoperations.deleteInsruance(Integer.parseInt(delete));
            request.removeAttribute("delete");
            System.out.println("Insurance " + delete + " has bee deleted");
            response.sendRedirect("/adminshowins.jsp");
            return;
        }
        String planid = request.getParameter("planid");
        String planname = request.getParameter("planname");
        String description = request.getParameter("description");
        String cost = request.getParameter("cost");
        if(planid == "" && planname == "" && description == "" && cost == ""){
            response.sendRedirect("/adminshowins.jsp");
            return;
        } else if(planid != "" && planname != "" && description != "" && cost != ""){
            Insurance ins = new Insurance(Integer.parseInt(planid), planname, description, Float.parseFloat(cost));
            if(DBoperations.insertInsurance(ins)){
                System.out.println("A new insurance has been created");
            }else{
                request.setAttribute("error", "PlanID has been used");
                System.out.println("PlanID has been used");
            }
        }else{
            request.setAttribute("error", "Incomplete Insurance Information");
            System.out.println("Incomplete Insurance Information");
        }
        response.sendRedirect("/adminshowins.jsp");
        return;
}

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
