package AdminServlets;

import Classes.Airport;
import Classes.DBoperations;
import Classes.MealPlan;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "AdminMpOperationServlet", urlPatterns = "/admin/AdminMpOperationServlet")
public class AdminMpOperationServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String newname = request.getParameter("newname");
        if(newname != null){
            DBoperations.mpUpdatename(Integer.parseInt(newname.substring(0,4)), newname.substring(4));
            System.out.println("Update meal plan name successfully");
            response.sendRedirect("/adminshowmp.jsp");
            return;
        }
        String delete = request.getParameter("delete");
        if(delete != null) {
            DBoperations.deleteMealPlan(Integer.parseInt(delete));
            request.removeAttribute("delete");
            System.out.println("Meal Plan " + delete + " has bee deleted");
            response.sendRedirect("/adminshowmp.jsp");
            return;
        }
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        if(id == "" && name == ""){
            response.sendRedirect("/adminshowmp.jsp");
            return;
        } else if(id != "" && name != ""){
            MealPlan mp = new MealPlan(Integer.parseInt(id), name);
            if(DBoperations.insertMealPlan(mp)){
                System.out.println("A new meal plan has been created");
            }else{
                request.setAttribute("error", "Meal plan id has been used");
                System.out.println("Meal plan id has been used");
            }
        }else{
            request.setAttribute("error", "Incomplete Meal Plan Information");
            System.out.println("Incomplete Meal Plan Information");
        }
        response.sendRedirect("/adminshowmp.jsp");
        return;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
