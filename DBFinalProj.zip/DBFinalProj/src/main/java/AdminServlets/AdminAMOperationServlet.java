package AdminServlets;

import Classes.AirModel;
import Classes.Airline;
import Classes.DBoperations;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "AdminAMOperationServlet", urlPatterns = "/admin/AdminAMOperationServlet")
public class AdminAMOperationServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String newnumoffleets = request.getParameter("newnumoffleets");
        if(newnumoffleets != null){
            DBoperations.amUpdateNumOfFleets(Integer.parseInt(newnumoffleets.substring(0,6)), Integer.parseInt(newnumoffleets.substring(6)));
            System.out.println("Update number of fleets successfully");
            response.sendRedirect("/adminshowairmodel.jsp");
            return;
        }
        String delete = request.getParameter("delete");
        if(delete != null) {
            DBoperations.deleteAirModel(Integer.parseInt(delete));
            request.removeAttribute("delete");
            System.out.println("AirModel " + delete + " has bee deleted");
            response.sendRedirect("/adminshowairmodel.jsp");
            return;
        }
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String manufacturer = request.getParameter("manufacturer");
        String numofengines = request.getParameter("numofengines");
        String numoffleets = request.getParameter("numoffleets");
        if(id == "" && name == "" && manufacturer == "" && numofengines == "" && numoffleets == ""){
            response.sendRedirect("/adminshowairmodel.jsp");
            return;
        } else if(id != "" && name != "" && manufacturer != "" && numofengines != "" && numoffleets != ""){
            AirModel am = new AirModel(Integer.parseInt(id), name, manufacturer, Integer.parseInt(numofengines), Integer.parseInt(numoffleets));
            if(DBoperations.insertAirModel(am)){
                System.out.println("A new air model has been created");
            }else{
                request.setAttribute("error", "Invalid model id");
                System.out.println("Invalid model id");
            }
        }else{
            request.setAttribute("error", "Incomplete AirModel Information");
            System.out.println("Incomplete AirModel Information");
        }
        response.sendRedirect("/adminshowairmodel.jsp");
        return;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
