package AdminServlets;

import Classes.Airport;
import Classes.DBoperations;
import Classes.Insurance;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "AdminApOperationServlet", urlPatterns = "/admin/AdminApOperationServlet")
public class AdminApOperationServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String delete = request.getParameter("delete");
        if(delete != null) {
            DBoperations.deleteAirport(delete);
            request.removeAttribute("delete");
            System.out.println("Airport " + delete + " has bee deleted");
            getServletContext().getRequestDispatcher("/adminshowairport.jsp").forward(request, response);
            return;
        }
        String code = request.getParameter("code");
        String name = request.getParameter("name");
        String city = request.getParameter("city");
        String country = request.getParameter("country");
        String type = request.getParameter("type");
        if(code == "" && name == "" && city == "" && country == "" && type == ""){
            getServletContext().getRequestDispatcher("/adminshowairport.jsp").forward(request, response);
            return;
        } else if(code != "" && name != "" && city != "" && country != "" && type != ""){
            Airport ap = new Airport(code, name, city, country, type);
            if(DBoperations.insertAirport(ap)){
                System.out.println("A new airport has been created");
            }else{
                request.setAttribute("error", "Invalid airport code");
                System.out.println("Invalid airport code");
            }
        }else{
            request.setAttribute("error", "Incomplete Airport Information");
            System.out.println("Incomplete Airport Information");
        }
        getServletContext().getRequestDispatcher("/adminshowairport.jsp").forward(request, response);
        return;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
