package AdminServlets;

import Classes.Airline;
import Classes.DBoperations;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "AdminAlOperationServlet", urlPatterns = "/admin/AdminAlOperationServlet")
public class AdminAlOperationServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String delete = request.getParameter("delete");
        if(delete != null) {
            DBoperations.deleteAirline(Integer.parseInt(delete));
            request.removeAttribute("delete");
            System.out.println("Airline " + delete + " has bee deleted");
            getServletContext().getRequestDispatcher("/adminshowairline.jsp").forward(request, response);
            return;
        }
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String mainhub = request.getParameter("mainhub");
        String headquarter = request.getParameter("headquarter");
        String country = request.getParameter("country");
        String airportcode = request.getParameter("airportcode");
        if(id == "" && name == "" && mainhub == "" && country == "" && headquarter == "" && airportcode == ""){
            getServletContext().getRequestDispatcher("/adminshowairline.jsp").forward(request, response);
            return;
        } else if(id != "" && name != "" && mainhub != "" && country != "" && airportcode != "" && headquarter != ""){
            Airline al = new Airline(Integer.parseInt(id), name, mainhub, headquarter, country, airportcode);
            if(DBoperations.insertAirline(al)){
                System.out.println("A new airport has been created");
            }else{
                request.setAttribute("error", "Invalid airline code or airport code");
                System.out.println("Invalid airline code or airport code");
            }
        }else{
            request.setAttribute("error", "Incomplete Airline Information");
            System.out.println("Incomplete Airline Information");
        }
        getServletContext().getRequestDispatcher("/adminshowairline.jsp").forward(request, response);
        return;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
