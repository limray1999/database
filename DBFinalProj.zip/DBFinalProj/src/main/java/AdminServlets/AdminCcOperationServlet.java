package AdminServlets;

import Classes.CabinClass;
import Classes.DBoperations;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "AdminCcOperationServlet", value = "/admin/AdminCcOperationServlet")
public class AdminCcOperationServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String newname = request.getParameter("newname");
        if(newname != null){
            DBoperations.ccUpdatename(Integer.parseInt(newname.substring(0,4)), newname.substring(4));
            System.out.println("Update cabin class name successfully");
            response.sendRedirect("/adminshowcc.jsp");
            return;
        }
        String delete = request.getParameter("delete");
        if(delete != null) {
            DBoperations.deleteCabinClass(Integer.parseInt(delete));
            request.removeAttribute("delete");
            System.out.println("Cabin class " + delete + " has bee deleted");
            response.sendRedirect("/adminshowcc.jsp");
            return;
        }
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        if(id == "" && name == ""){
            response.sendRedirect("/adminshowcc.jsp");
            return;
        } else if(id != "" && name != ""){
            CabinClass cc = new CabinClass(Integer.parseInt(id), name);
            if(DBoperations.insertCabinClass(cc)){
                System.out.println("A new Cabin class has been created");
            }else{
                request.setAttribute("error", "Cabin class id has been used");
                System.out.println("Cabin class id has been used");
            }
        }else{
            request.setAttribute("error", "Incomplete Cabin class Information");
            System.out.println("Incomplete Cabin class Information");
        }
        response.sendRedirect("/adminshowcc.jsp");
        return;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
