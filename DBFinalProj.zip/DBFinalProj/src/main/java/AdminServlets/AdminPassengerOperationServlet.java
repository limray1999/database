package AdminServlets;

import Classes.DBoperations;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "AdminPassengerOperationServlet", urlPatterns = "/admin/AdminPassengerOperationServlet")
public class AdminPassengerOperationServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String delete = request.getParameter("delete");
        if(delete != null) {
            DBoperations.deletePassenger(Integer.parseInt(delete));
            request.removeAttribute("delete");
            System.out.println("Passenger " + delete + " has bee deleted");
            response.sendRedirect("/adminshowpassenger.jsp");
            return;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
