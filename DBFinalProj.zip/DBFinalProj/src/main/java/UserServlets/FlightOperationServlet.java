package UserServlets;

import Classes.DBoperations;
import Classes.LoginAccount;
import Classes.PasFliDate;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import javax.swing.*;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet(name = "FlightOperationServlet", urlPatterns = "/user/FlightOperationServlet")
public class FlightOperationServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String delete = request.getParameter("delete");
        if(delete != null){
            String[] str = delete.split("\\s+");
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            try {
                DBoperations.deletePasFliDate(Integer.parseInt(str[0]), Integer.parseInt(str[1]), df.parse(str[2]));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            getServletContext().getRequestDispatcher("/flight.jsp").forward(request,response);
            return;
        }
        int pid = (int) request.getSession().getAttribute("user");
        String fid = request.getParameter("fid");
        String date = request.getParameter("date");
        String mpid = request.getParameter("mpid");
        String ccid = request.getParameter("ccid");
        String srid = request.getParameter("srid");
        if(fid==""&&date==""&&mpid==""&&ccid==""&&srid==""){
            getServletContext().getRequestDispatcher("/flight.jsp").forward(request,response);
            return;
        }else if(fid!=""&&date!=""&&mpid!=""&&ccid!=""&&srid!=""){
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            try {
                PasFliDate pfd = new PasFliDate(100005, Integer.parseInt(fid), df.parse(date), Integer.parseInt(mpid), Integer.parseInt(ccid), Integer.parseInt(srid));
                if(DBoperations.insertPasFliDate(pfd)){
                    System.out.println("New PasFliDate has been created");
                    getServletContext().getRequestDispatcher("/flight.jsp").forward(request,response);
                    return;
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }else{
            request.setAttribute("error", "Incomplete information");
            getServletContext().getRequestDispatcher("/flight.jsp").forward(request,response);
            return;
        }
        getServletContext().getRequestDispatcher("/flight.jsp").forward(request,response);
        return;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
