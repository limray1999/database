package UserServlets;

import Classes.DBoperations;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "ProvideInfoServlet", urlPatterns = "/user/provideinfo")
public class ProvideInfoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if(DBoperations.customerValidate((int) request.getSession().getAttribute("user"))){
            getServletContext().getRequestDispatcher("/provideinfo.jsp").forward(request,response);
            return;
        }else{
            getServletContext().getRequestDispatcher("/registercustomer.jsp").forward(request,response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
