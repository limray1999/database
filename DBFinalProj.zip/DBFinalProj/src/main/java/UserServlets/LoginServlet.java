package UserServlets;

import Classes.LoginAccount;
import Classes.DBoperations;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "LoginServlet", urlPatterns = "/login")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        int passengerid = DBoperations.getUserPid(username);
        if (DBoperations.validate(username, password)) {
            request.getSession().setAttribute("user", passengerid);
            request.getSession().setAttribute("username", username);
            System.out.println("User "+ username +" login successfully");
            getServletContext().getRequestDispatcher("/home.jsp").forward(request, response);
        } else {
            request.setAttribute("error", "Username or password is wrong");
            getServletContext().getRequestDispatcher("/login.jsp").forward(request,response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getSession().removeAttribute("user");
        request.getSession().removeAttribute("username");
        getServletContext().getRequestDispatcher("/welcome.jsp").forward(request, response);
    }
}
