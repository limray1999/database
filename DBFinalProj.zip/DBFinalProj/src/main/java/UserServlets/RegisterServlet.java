package UserServlets;

import Classes.DBoperations;
import Classes.LoginAccount;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "RegisterServlet", urlPatterns = "/register")
public class RegisterServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        getServletContext().getRequestDispatcher("/register.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String comfirm = request.getParameter("comfirm");
        if(username == "" || password == "" || comfirm == ""){
            request.setAttribute("error", "Incomplete information");
            doGet(request,response);
        }else if(!password.equals(comfirm)) {
            request.setAttribute("error", "Passwords do not match");
            doGet(request,response);
        }else{
            LoginAccount account = new LoginAccount(username, password);
            if(DBoperations.insertLoginAccount(account)){
                request.setAttribute("pid", account.getPassengerid());
                getServletContext().getRequestDispatcher("/registerpassenger.jsp").forward(request, response);
            }else{
                request.setAttribute("error", "username has been used");
                doGet(request, response);
            }
        }
    }
}
