package UserServlets;

import Classes.BookingAgent;
import Classes.DBoperations;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "RegisterBookingAgentServlet", urlPatterns = "/registerba")
public class RegisterBookingAgentServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int pid = (int) request.getSession().getAttribute("user");
        String name = request.getParameter("name");
        String web = request.getParameter("web");
        String phonenumber = request.getParameter("phonenumber");
        BookingAgent ba = new BookingAgent(pid, name, web, phonenumber);
        if(DBoperations.insertBA(ba)){
            System.out.println("New ba has been created");
            getServletContext().getRequestDispatcher("/login.jsp").forward(request,response);
        }else {
            getServletContext().getRequestDispatcher("/registerba.jsp").forward(request,response);
        }

    }
}
