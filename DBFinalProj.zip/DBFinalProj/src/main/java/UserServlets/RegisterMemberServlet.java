package UserServlets;

import Classes.DBoperations;
import Classes.MemberShip;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@WebServlet(name = "RegisterMemberServlet", urlPatterns = "/registermb")
public class RegisterMemberServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int pid = (int) request.getSession().getAttribute("user");
        String name = request.getParameter("name");
        String airline = request.getParameter("associatedairline");
        String startdate = request.getParameter("startdate");
        String enddate = request.getParameter("enddate");
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        if(enddate==""){
            try {
                MemberShip mb = new MemberShip(pid,name,airline,df.parse(startdate));
                if(DBoperations.insertMB(mb)){
                    System.out.println("New mb has been created");
                }else{
                    getServletContext().getRequestDispatcher("/registermb.jsp").forward(request,response);
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }else{
            try {
                MemberShip mb = new MemberShip(pid,name,airline,df.parse(startdate),df.parse(enddate));
                if(DBoperations.insertMB(mb)){
                    System.out.println("New mb has been created");
                }else{
                    getServletContext().getRequestDispatcher("/registermb.jsp").forward(request,response);
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        getServletContext().getRequestDispatcher("/login.jsp").forward(request,response);
    }
}
