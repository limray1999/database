package UserServlets;

import Classes.DBoperations;
import Classes.Payment;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet(name = "PayServlet", urlPatterns = "/user/pay")
public class PayServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        getServletContext().getRequestDispatcher("/pay.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int paymentid = DBoperations.next_payment_id();
        float amount = Float.parseFloat(request.getParameter("amount"));
        String method = request.getParameter("method");
        int cardnumber = Integer.parseInt(request.getParameter("cardnumber"));
        String fname = request.getParameter("fname");
        String lname = request.getParameter("lname");
        int invnumber = Integer.parseInt(request.getParameter("invnumber"));
        Date paymentdate = new java.util.Date();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date edate = df.parse(request.getParameter("edate"));
            Payment payment = new Payment(paymentid,amount,method,cardnumber,fname,lname,edate,invnumber,paymentdate);
            if(DBoperations.insertPayment(payment)){
                System.out.println("Payment has been submitted");
                getServletContext().getRequestDispatcher("/order.jsp").forward(request,response);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}
