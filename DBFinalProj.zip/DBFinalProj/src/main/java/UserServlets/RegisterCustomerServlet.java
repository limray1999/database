package UserServlets;

import Classes.Customer;
import Classes.DBoperations;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "RegisterCustomerServlet", urlPatterns = "/registercustomer")
public class RegisterCustomerServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int pid = (int) request.getSession().getAttribute("user");
        String street = request.getParameter("Street");
        String city = request.getParameter("City");
        String state = request.getParameter("State");
        String zipcode = request.getParameter("ZipCode");
        String country = request.getParameter("Country");
        String email = request.getParameter("Email");
        String contactnumber = request.getParameter("ContactNumber");
        String efname = request.getParameter("EFName");
        String elname = request.getParameter("ELName");
        String econtect = request.getParameter("EContact");
        String customertype = request.getParameter("CustomerType");
        Customer cus = new Customer(pid,street,city,state,zipcode,country,email,contactnumber,efname,elname,econtect,customertype);
        if(DBoperations.insertCustomer(cus)){
            System.out.println("New customer has been created");
            if(customertype.equals("C")){
                getServletContext().getRequestDispatcher("/login.jsp").forward(request,response);
            }else if(customertype.equals("B")){
                getServletContext().getRequestDispatcher("/registerba.jsp").forward(request,response);
            }else{
                getServletContext().getRequestDispatcher("/registermb.jsp").forward(request,response);
            }
        }else {
            getServletContext().getRequestDispatcher("/registercustomer.jsp").forward(request,response);
        }
    }
}
