package UserServlets;

import Classes.DBoperations;
import Classes.Invoice;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet(name = "BuyInsServlet", urlPatterns = "/user/buyins")
public class BuyInsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int passengerid = (int) request.getSession().getAttribute("user");
        int planid = Integer.parseInt(request.getParameter("planid"));
        int coverageid = Integer.parseInt(request.getParameter("coverageid"));
        int flightid = Integer.parseInt(request.getParameter("flightid"));
        String flightdate = request.getParameter("flightdate");
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date fdate = df.parse(flightdate);
            Invoice inv = new Invoice(DBoperations.next_inv_number(), fdate, DBoperations.getCost(planid));
            if(DBoperations.insertInvoice(inv)&&DBoperations.insertPasIns(planid,coverageid,flightid,fdate)&&DBoperations.insertCusIns(coverageid,planid,passengerid,flightid,fdate,inv.getInvoicenumber())){
                System.out.println("Buy insurance successfully");
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        getServletContext().getRequestDispatcher("/home.jsp").forward(request,response);
    }
}
