package UserServlets;

import Classes.DBoperations;
import Classes.Passenger;
import org.omg.CORBA.portable.ApplicationException;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

@WebServlet(name = "RegisterPassengerServlet", urlPatterns = "/registerpassenger")
public class RegisterPassengerServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pid = request.getParameter("pid");
        String fname = request.getParameter("FirstName");
        String lname = request.getParameter("LastName");
        String birthday = request.getParameter("Birthday");
        String nationality = request.getParameter("Nationality");
        String gender = request.getParameter("Gender");
        String ppnumber = request.getParameter("PassportNumber");
        String ppetexpirydate = request.getParameter("PassportExpiryDate");
        String type = request.getParameter("PassengerType");
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        if(pid==""||fname==""||lname==""||birthday==""||nationality==""||gender==""||ppnumber==""||ppetexpirydate ==""||type==""){
            request.setAttribute("error", "Incomplete information");
            getServletContext().getRequestDispatcher("/registerpassenger.jsp").forward(request,response);
        }else{
            try {
                Date bd = df.parse(birthday);
                Date pped = df.parse(ppetexpirydate);
                Passenger pass = new Passenger(Integer.parseInt(pid),fname,lname,bd,nationality,gender,ppnumber,pped,type);
                if(DBoperations.insertPassenger(pass)){
                    System.out.println("New Passenger Created");
                }else{
                    System.out.println("Wrong Information");
                    request.setAttribute("error", "Wrong Information");
                    getServletContext().getRequestDispatcher("/registerpassenger.jsp").forward(request,response);
                }
                if(type.equals("P")){
                    response.sendRedirect("/login.jsp");
                }else{
                    request.getSession().setAttribute("user", pass.getPassengerID());

                    getServletContext().getRequestDispatcher("/registercustomer.jsp").forward(request,response);
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }
}
