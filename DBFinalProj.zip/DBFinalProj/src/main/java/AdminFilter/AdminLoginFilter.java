package AdminFilter;

import Classes.LoginAccount;

import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter(filterName = "AdminLoginFilter",
        urlPatterns = {"/admin/*", "/adminhome.jsp", "/adminshowuser.jsp", "/adminshowins.jsp", "/adminshowairport.jsp",
                "/adminshowmodel.jsp", "/adminshowmp.jsp", "/adminshowsr.jsp", "/adminshowcc.jsp", "/adminshowpassenger.jsp",
                "/adminshowairmodel.jsp"})
public class AdminLoginFilter implements Filter {
    public void init(FilterConfig config) throws ServletException {

    }

    public void destroy() {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws ServletException, IOException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        Object account = req.getSession().getAttribute("user");
        if(account != null){
            chain.doFilter(req, resp);
        }else{
            req.getRequestDispatcher("/admin/login").forward(req, resp);
        }

    }
}
